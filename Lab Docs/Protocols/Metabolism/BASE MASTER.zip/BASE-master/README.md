BASE
====

Fast processing of diel oxygen curves: estimating stream metabolism with BASE (BAyesian Single-station Estimation) 
Grace et al. 2015 Limnol. Oceanogr.: Methods 13, 2015, 103–114

PDF user guide included in zip file.
